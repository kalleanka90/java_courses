package cb223ea_assign2;

public class PinkFloyd {
    public static void main(String[] args) {

        // The for-loop prints the String "Pink Floyd rules!" 5 times
        for (int i = 0; i < 5; i++) {
            System.out.println("Pink Floyd rules!");
        }
    }
}
